# Presto-Ride-Sharing-App
Alloy file: alloy.als

FSP file: presto-ver2.lts

GitHub Repo: https://github.com/AndrewChang-cpu/Presto-Ride-Sharing-App 